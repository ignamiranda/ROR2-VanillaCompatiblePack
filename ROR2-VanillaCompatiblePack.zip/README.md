# VanillaCompatiblePack
A Risk of Rain 2 modpack that lets you play with vanilla players.

Report any issues on [Github](https://github.com/ignamiranda/VanillaCompatiblePack/issues).
